$(window).on('load', function () {
	$('#status').fadeOut();
	$('#preloader').delay(800).fadeOut('slow');
	//slow makes the preloader fade out slowly

});